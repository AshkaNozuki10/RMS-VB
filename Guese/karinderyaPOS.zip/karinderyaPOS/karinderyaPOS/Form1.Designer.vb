﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        qweqwe = New Panel()
        Button6 = New Button()
        Button5 = New Button()
        Button3 = New Button()
        Button4 = New Button()
        btnClose = New Button()
        Button1 = New Button()
        Button2 = New Button()
        Panel1 = New Panel()
        DnT = New Button()
        qwe = New Panel()
        Button8 = New Button()
        Button7 = New Button()
        Label13 = New Label()
        Label12 = New Label()
        Label11 = New Label()
        Label10 = New Label()
        Label9 = New Label()
        Label8 = New Label()
        Label7 = New Label()
        Label6 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        qweqwe.SuspendLayout()
        qwe.SuspendLayout()
        SuspendLayout()
        ' 
        ' qweqwe
        ' 
        qweqwe.BackColor = Color.Gray
        qweqwe.Controls.Add(Button6)
        qweqwe.Controls.Add(Button5)
        qweqwe.Controls.Add(Button3)
        qweqwe.Controls.Add(Button4)
        qweqwe.Controls.Add(btnClose)
        qweqwe.Controls.Add(Button1)
        qweqwe.Controls.Add(Button2)
        qweqwe.Dock = DockStyle.Top
        qweqwe.Location = New Point(0, 0)
        qweqwe.Name = "qweqwe"
        qweqwe.Size = New Size(946, 45)
        qweqwe.TabIndex = 1
        ' 
        ' Button6
        ' 
        Button6.BackColor = Color.Gray
        Button6.FlatAppearance.BorderSize = 0
        Button6.FlatStyle = FlatStyle.Flat
        Button6.Font = New Font("Ebrima", 14.25F)
        Button6.Location = New Point(727, 0)
        Button6.Name = "Button6"
        Button6.Size = New Size(150, 45)
        Button6.TabIndex = 7
        Button6.Text = "Drinks"
        Button6.UseVisualStyleBackColor = False
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.Gray
        Button5.FlatAppearance.BorderSize = 0
        Button5.FlatStyle = FlatStyle.Flat
        Button5.Font = New Font("Ebrima", 14.25F)
        Button5.Location = New Point(587, 0)
        Button5.Name = "Button5"
        Button5.Size = New Size(150, 45)
        Button5.TabIndex = 5
        Button5.Text = "Speacial"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.Gray
        Button3.FlatAppearance.BorderSize = 0
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Ebrima", 14.25F)
        Button3.Location = New Point(293, 0)
        Button3.Name = "Button3"
        Button3.Size = New Size(150, 45)
        Button3.TabIndex = 4
        Button3.Text = "Veggie"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.Gray
        Button4.FlatAppearance.BorderSize = 0
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Ebrima", 14.25F)
        Button4.Location = New Point(440, 0)
        Button4.Name = "Button4"
        Button4.Size = New Size(150, 45)
        Button4.TabIndex = 6
        Button4.Text = "Seafood"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' btnClose
        ' 
        btnClose.BackColor = Color.Transparent
        btnClose.FlatStyle = FlatStyle.Flat
        btnClose.Font = New Font("Verdana", 11.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClose.ForeColor = Color.Black
        btnClose.Location = New Point(883, 0)
        btnClose.Name = "btnClose"
        btnClose.Size = New Size(63, 45)
        btnClose.TabIndex = 6
        btnClose.Text = "X"
        btnClose.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.Gray
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Ebrima", 14.25F)
        Button1.Location = New Point(0, 0)
        Button1.Name = "Button1"
        Button1.Size = New Size(150, 45)
        Button1.TabIndex = 2
        Button1.Text = "Featured"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.Gray
        Button2.FlatAppearance.BorderSize = 0
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Ebrima", 14.25F)
        Button2.Location = New Point(147, 0)
        Button2.Name = "Button2"
        Button2.Size = New Size(150, 45)
        Button2.TabIndex = 3
        Button2.Text = "Meat"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Panel1
        ' 
        Panel1.Dock = DockStyle.Fill
        Panel1.Location = New Point(232, 45)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(714, 527)
        Panel1.TabIndex = 5
        ' 
        ' DnT
        ' 
        DnT.FlatAppearance.BorderSize = 0
        DnT.FlatStyle = FlatStyle.Flat
        DnT.Image = CType(resources.GetObject("DnT.Image"), Image)
        DnT.Location = New Point(203, 68)
        DnT.Name = "DnT"
        DnT.Size = New Size(29, 23)
        DnT.TabIndex = 0
        DnT.UseVisualStyleBackColor = True
        ' 
        ' qwe
        ' 
        qwe.BackColor = Color.Gray
        qwe.Controls.Add(Button8)
        qwe.Controls.Add(Button7)
        qwe.Controls.Add(Label13)
        qwe.Controls.Add(Label12)
        qwe.Controls.Add(Label11)
        qwe.Controls.Add(Label10)
        qwe.Controls.Add(Label9)
        qwe.Controls.Add(Label8)
        qwe.Controls.Add(Label7)
        qwe.Controls.Add(Label6)
        qwe.Controls.Add(DnT)
        qwe.Controls.Add(Label5)
        qwe.Controls.Add(Label4)
        qwe.Controls.Add(Label3)
        qwe.Controls.Add(Label2)
        qwe.Controls.Add(Label1)
        qwe.Dock = DockStyle.Left
        qwe.Location = New Point(0, 45)
        qwe.Name = "qwe"
        qwe.Size = New Size(232, 527)
        qwe.TabIndex = 0
        ' 
        ' Button8
        ' 
        Button8.FlatStyle = FlatStyle.Flat
        Button8.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button8.Location = New Point(125, 458)
        Button8.Name = "Button8"
        Button8.Size = New Size(75, 33)
        Button8.TabIndex = 11
        Button8.Text = "Charge"
        Button8.UseVisualStyleBackColor = True
        ' 
        ' Button7
        ' 
        Button7.FlatStyle = FlatStyle.Flat
        Button7.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button7.Location = New Point(21, 458)
        Button7.Name = "Button7"
        Button7.Size = New Size(75, 33)
        Button7.TabIndex = 0
        Button7.Text = "Clear"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Ebrima", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label13.Location = New Point(12, 395)
        Label13.Name = "Label13"
        Label13.Size = New Size(68, 21)
        Label13.TabIndex = 10
        Label13.Text = "Change"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Ebrima", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(12, 362)
        Label12.Name = "Label12"
        Label12.Size = New Size(53, 21)
        Label12.TabIndex = 9
        Label12.Text = "Total:"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Location = New Point(0, 332)
        Label11.Name = "Label11"
        Label11.Size = New Size(232, 15)
        Label11.TabIndex = 1
        Label11.Text = "_____________________________________________"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Location = New Point(0, 94)
        Label10.Name = "Label10"
        Label10.Size = New Size(232, 15)
        Label10.TabIndex = 8
        Label10.Text = "_____________________________________________"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(0, 267)
        Label9.Name = "Label9"
        Label9.Size = New Size(232, 15)
        Label9.TabIndex = 0
        Label9.Text = "_____________________________________________"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Ebrima", 8.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(12, 319)
        Label8.Name = "Label8"
        Label8.Size = New Size(55, 13)
        Label8.TabIndex = 7
        Label8.Text = "Discount: "
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Ebrima", 8.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(12, 292)
        Label7.Name = "Label7"
        Label7.Size = New Size(56, 13)
        Label7.TabIndex = 6
        Label7.Text = "Tax / VAT:"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Ebrima", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(12, 109)
        Label6.Name = "Label6"
        Label6.Size = New Size(51, 21)
        Label6.TabIndex = 5
        Label6.Text = "Items:"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Ebrima", 8.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(125, 73)
        Label5.Name = "Label5"
        Label5.Size = New Size(0, 13)
        Label5.TabIndex = 4
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Ebrima", 8.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(12, 73)
        Label4.Name = "Label4"
        Label4.Size = New Size(84, 13)
        Label4.TabIndex = 3
        Label4.Text = "Date and Time: "
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Ebrima", 8.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(99, 46)
        Label3.Name = "Label3"
        Label3.Size = New Size(118, 13)
        Label3.TabIndex = 2
        Label3.Text = "Margaux Cimon Guese"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Ebrima", 8.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(12, 46)
        Label2.Name = "Label2"
        Label2.Size = New Size(81, 13)
        Label2.TabIndex = 1
        Label2.Text = "Cashier Name: "
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Ebrima", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(12, 15)
        Label1.Name = "Label1"
        Label1.Size = New Size(128, 17)
        Label1.TabIndex = 0
        Label1.Text = "CASHIER POS TOTAL"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(946, 572)
        Controls.Add(Panel1)
        Controls.Add(qwe)
        Controls.Add(qweqwe)
        FormBorderStyle = FormBorderStyle.None
        Name = "Form1"
        Text = "Form1"
        qweqwe.ResumeLayout(False)
        qwe.ResumeLayout(False)
        qwe.PerformLayout()
        ResumeLayout(False)
    End Sub
    Friend WithEvents qweqwe As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents qwe As Panel
    Friend WithEvents btnClose As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents DnT As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label

End Class
